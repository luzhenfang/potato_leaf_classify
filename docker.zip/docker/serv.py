import json

from PIL import Image
from flask import Flask, request, make_response, send_file
import torch
from flask_cors import CORS
from net import ResNet
from classify_label import index_to_label
from torchvision import transforms

MODEL_PATH = "/data/model.pth"
CRT_APTH = "/data/server.crt"
KEY_PATH = "/data/server.key"
app = Flask(__name__)
# 开启跨域
CORS(app, supports_credentials=True)


# 加载模型
def load_mode():
    net = torch.load(MODEL_PATH, map_location=torch.device("cpu"))
    return net


# 模型预测
def predict(net, input):
    output = net(input)
    conf, pre = torch.max(torch.softmax(output, dim=1), dim=1)
    print(conf.item())
    return str(conf.item())[:8], pre.item()


# 图像增强
def trans_img(img):
    trans = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.5, 0.5, 0.5))
    ])
    return trans(img)


# 预测接口
@app.route("/predict", methods=["post"])
def index():
    try:
        file = request.files.get("file")
        img = Image.open(file.stream)
        img = trans_img(img)
        conf, val = predict(load_mode(), torch.reshape(img, (1, 3, 224, 224)))
        resp = {
            "code": 200,
            "msg": "识别成功!",
            "type": index_to_label[val],
            "conf": conf
        }
        return json.dumps(resp, ensure_ascii=False)
    except Exception as e:
        print(e)
        return json.dumps({
            "code": -1,
            "msg": "服务器出现异常!"
        })


if __name__ == '__main__':
    # ssl
    app.run(host="0.0.0.0", port=8080,ssl_context=(CRT_APTH, KEY_PATH))
